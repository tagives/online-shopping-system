public class OrderItem {
    private Product product;
    private int quantity;
    private double unitPrice;

    public double getTotalPrice() {
        return 0.0;
    }
}
