
public class Review {
    

    public void editReview(int newRating, String newComment) {}
}
