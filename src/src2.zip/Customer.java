

public class Customer extends User {
    
    public void addToCart(Product product, int quantity) {}

    public Order placeOrder() {
        return null;
    }
}
