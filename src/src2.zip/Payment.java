public interface Payment {
    boolean processPayment(double amount);
}
