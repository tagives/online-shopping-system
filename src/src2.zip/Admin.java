public class Admin extends User {
    public void addProduct(Product product) {}

    public void removeProduct(String productId) {}

    public void updateStock(String productId, int quantity) {}
}
